Python implementation of the Git file formats and protocols,
without the need to have git installed.

All functionality is available in pure Python. Optional
C extensions can be built for improved performance.

The project is named after the part of London that Mr. and Mrs. Git live in
in the particular Monty Python sketch.


